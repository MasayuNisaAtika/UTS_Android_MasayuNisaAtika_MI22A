package com.uts_masayunisaatika

data class Course(

    val title: String,
    val path: String,
    val image: String
)

package com.uts_masayunisaatika

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import com.uts_masayunisaatika.databinding.ActivityMainBinding
import cz.msebera.android.httpclient.Header
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    lateinit var view : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        view = ActivityMainBinding.inflate(layoutInflater)
        setContentView(view.root)

        var url = "https://fahram.dev/api/v2/courses"

        var client = AsyncHttpClient()
        client.get(url, object : AsyncHttpResponseHandler(){
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?
            ) {
                val response = responseBody?.let { String(it) }
                val responseObj = JSONObject(response)
                val data = responseObj.getJSONArray("data")
                val courses = ArrayList<Course>()
                for (i in 0 until data.length()) {
                    val jsonObj = data.getJSONObject(i)
                    val title = jsonObj.getString("title")
                    val path = jsonObj.getString("path")
                    val image = jsonObj.getString("image")

                    val course = Course(title, path, image)
                    courses.add(course)
                }
                val adapter = CourseAdapter(courses)
                view.rvCourse.layoutManager = LinearLayoutManager(this@MainActivity)
                view.rvCourse.adapter = adapter
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                Log.d("ERROR :", error.toString())
            }

        })
    }
}